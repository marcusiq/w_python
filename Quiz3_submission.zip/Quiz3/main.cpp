#include <iostream>
int drink_count=0;
void stumble(){
    printf("Walking into poles has really become your thing\n");
}
void stable(){
    printf("Your a pro at walking, has anyone told you that\n");
}
void isDrunk() {
    if (drink_count > 5) {
        stumble();
    } else {
        stable();
    }
    if (drink_count > 12) {
        printf("Wow you had way too much its time to go home pal\n");
    }
}
void swig(int n){
    switch(n){
        case 4:
            printf("You slam your whiskey down\n");
            drink_count = drink_count +1;
            break;
        case 3:
            printf("CHUG CHUG CHUG, what a nice beer\n");
            drink_count= drink_count +1;
            break;
        case 2:
            printf("You slam your vodka down\n");
            drink_count= drink_count +1;
            break;
        case 1:
            printf("You slam your Rum down\n");
            drink_count= drink_count +1;
            break;
        default:
            printf("You dummy you still arent choosing the right number, your more drunk than you look\n");

    }
}


int main() {
//   char v = "list for all i care";
    //   printf(char); ALL PARTS AND THE LIKE
    //  TIME TO RELAX HAVE AS MANY DRINKS AS YOU CAN UNTIL YOU CAN'T ANYMORE
    int drinks;
    for (int i = 0; i <= 25; i++) {
        int b = i * 2;
        int *h = &b;
        printf("\tThisis b %i\n", b);
        printf("\tThis is the address of b, %p\n",
               h); // as you can see even though the value is changing the address doesn't

    }
    while (true) {
        printf("What would you like 1: Rum, 2: Vodka, 3: Beer, 4: Whiskey\n");
        scanf("%d", &drinks);
        //if (drinks != 1, 2, 3, 4) {
          //  printf("You did not choose one of the options, chose again\n");
            //continue; // My poor attempt to stop you from inputing something other than the options
        //}
        swig(drinks);
        isDrunk();
        if (drink_count > 12) {
            break;
        }
    }

//    for (int v = 20; v>0; v=v-v*(.3) +0.5) { // If you run this code it will go forever, try it out!!!!!!!!
    //      printf("\tThis is some value %d\n",v);

    //} // ME JUST MESSING AROUND WITH ODD THINGS IN C
//    int t = 5;
    //   int *g = &t;
    // printf("%p\n", g); // testing out pointers
    // double trie[20];
    // for (int u = 0; u<19;u++) {
    //    trie[u] = u;
    // }
    // for (int i = 0;i<19;i++)
    // printf("%g",trie);

//}
}